module.exports = {
  base_url: "https://13.200.247.29:4000",
  APPLICATION_KEY: "",
  APPLICATION_SECRET: "",
  fcm_serverKey: "",
  live_base_url :"https://ekotrace.ekobon.com:4000/"
  // live_base_url :"http://13.200.247.29:4000/"
};
