const db = require("../utils/database");
const config = require("../config");
const baseurl = config.base_url;

module.exports = {

getOffsetByCountry : ( async(country,country_id) => {
    return db.query('select * from hotel_booking where country = ? and country_id = ?',[country,country_id]);
}),

  getLatLongByCode :(async (ap_code) => {
    return db.query('select * from 	flight_airport_code where airport_code = ?',[ap_code]);
}),

getFlightParams : (async(search_str,country_id ) => {
  return db.query('SELECT  * FROM flight_semantics WHERE distance = ? and country_id=? ',[search_str,country_id]);
}),


getemssiomFactor : (async(sub_category) => {
  return db.query('SELECT  * FROM emission_factors WHERE sub_category = ?',[sub_category]);
}),

Othermodes_of_transport: async (user) => {
  return db.query("insert into other_modes_of_transport  set ?", [user]);
},

hotelStay: async (user) => {
  return db.query("insert into hotel_stay  set ?", [user]);
},

flight_travel: async (user) => {
  return db.query("insert into flight_travel  set ?", [user]);
},

insertbusinessunitsetting: async (user) => {
  return db.query("insert into business_unit_setting  set ?", [user]);
},

insertemployee_commuting_category: async (data) => {
  return db.query("INSERT INTO  `employee_commuting_category` (noofemployees,workingdays,totalnoofcommutes,typeoftransport,subtype,allemployeescommute,avgcommutedistance,emission,EFs,unit,user_id,batch,facilities,year,month) VALUES ?",
  [data.map((item) => [
    item.noofemployees,
    item.workingdays,
    item.totalnoofcommutes,
    item.typeoftransport,
    item.subtype,
    item.allemployeescommute,
    item.avgcommutedistance,
    item.emission,
    item.EFs,
    item.unit,
    item.user_id,
    item.batch,
     item.facilities,
     item.year,
     item.month
])]);
},

homeoffice_emission_factors : (async(type,country_id) => {
  let where = '';
  if(country_id){
    where  = `  and country_id = ?`;
  }
  return db.query(`SELECT  * FROM homeoffice_emission_factors WHERE id = ? ${where}`,[type,country_id]);
}),


homeoffice_emission_category: async (data) => {
  return db.query("INSERT INTO  `homeoffice_category` (typeofhomeoffice,noofemployees,noofdays,noofmonths,emission,user_id,batch,facilities,year,month) VALUES ?",
  [data.map((item) => [
    item.typeofhomeoffice,
    item.noofemployees,
    item.noofdays,
    item.noofmonths,
    item.emission,
    item.user_id,
    item.batch,
    item.facilities,
    item.year,
    item.month
])]);
},


soldproductsemission_factors : (async(productcategory,country_id) => {

  return db.query('SELECT  * FROM sold_product_category_ef WHERE item = ? and country_id = ?',[productcategory,country_id]);
}),


insertsoldproductsemission: async (product) => {
  return db.query("insert into sold_product_category  set ?", [product]);
},


insertendof_lifetreatment_category: async (product) => {
  return db.query("insert into endof_lifetreatment_category  set ?", [product]);
},


endof_lifeSubCatmission_factors : (async(productcategory,country_id) => {

  return db.query('SELECT  * FROM endoflife_waste_type_subcategory WHERE type = ? and country_id = ?',[productcategory,country_id]);
}),


endoflife_waste_type : (async(productcategory,country_id) => {

 let countrydata = ''; 
if(country_id){
  countrydata =  ` and country_id = '${country_id}'`;
}
  return db.query(`SELECT  * FROM 	endoflife_waste_type WHERE id = ?  ${countrydata}`,[productcategory]);
}),


water_supply_treatment_type : (async(id ,country_id) => {
  return db.query(`SELECT  * FROM 	water_supply_treatment_type where id = '${id}' and country_id ='${country_id}' `);
}),


insertwater_supply_treatment_category: async (product) => {
  return db.query("insert into water_supply_treatment_category  set ?", [product]);
},

insert_water_withdrawl_by_source: async (data) => {
  return db.query(`INSERT INTO  water_withdrawl_by_source (kilolitres,water_withdrawl,user_id,water_supply_treatment_id,month,year,totalwaterwithdrawl) VALUES ?`,
  [data.map((item) => [
    item.kilolitres,
    item.water_withdrawl,
    item.user_id,
    item.water_supply_treatment_id,
    item.month,
    item.year,
    item.totalwaterwithdrawl
])]);
},


insert_water_discharge_by_destination: async (data) => {
  return db.query(`INSERT INTO   water_discharge_by_destination (water_discharge,withthtreatment,leveloftreatment,user_id,water_supply_treatment_id,month,year,totalwaterdischarge) VALUES ?`,
  [data.map((item) => [
    item.water_discharge,
    item.withthtreatment,
    item.leveloftreatment,
    item.user_id,
    item.water_supply_treatment_id,
    item.month,
    item.year,
    item.totalwaterdischarge
])]);
},

insert_water_discharge_by_destination_only: async (data) => {
  return db.query(`INSERT INTO   water_discharge_by_destination_only (water_discharge,kilolitres,user_id,water_supply_treatment_id,month,year,totaldischarge) VALUES ?`,
  [data.map((item) => [
    item.water_discharge,
    item.kilolitres,
    item.user_id,
    item.water_supply_treatment_id,
    item.month,
    item.year,
    item.totaldischarge
])]);
},

insertprocessing_of_sold_productsCategory: async (product) => {
  return db.query("insert into processing_of_sold_products_category  set ?", [product]);
},
insertprocessing_of_sold_products_ef: async (product) => {
  return db.query("insert into processing_of_sold_products_ef  set ?", [product]);
},

updateWater_ef: async (emission,id) => {
  return db.query("UPDATE water_supply_treatment_category set emission = ? where id= ?", [emission,id]);
},

}